# Reviews & Sentiment Dashboard — Enterprise Deliverable

Start with `docs/enterprise_blueprint.md` — it contains the architecture
diagram, the Power BI star schema, all DAX measures, dashboard layout,
and governance/deployment guidance.

```
reviews_sentiment_dashboard/
├── README.md                          ← you are here
├── requirements.txt                   ← pip install -r requirements.txt
├── docs/
│   └── enterprise_blueprint.md        ← architecture + Power BI + DAX + governance
└── pipeline/
    ├── pii_scrubber.py                ← PII redaction (regex + spaCy + optional Presidio)
    ├── sentiment_topic_analysis.py    ← sentiment (VADER/Azure) + topic modeling (BERTopic/LDA)
    ├── validation.py                  ← Precision/Recall/F1 CI gate against a labeled set
    ├── drift_monitor.py               ← PSI + KS-test drift detection
    └── main.py                        ← orchestrates the above, writes the star schema

data/                                  ← put raw_reviews.csv and validation_set.csv here (gitignored)
└── raw_reviews_sample_650.csv         ← ready-to-use 566-row synthetic dataset (see below)
```

## Quickstart

```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm   # only needed for name/location PII detection

python pipeline/main.py --input data/raw_reviews.csv --output-dir data/curated
python pipeline/validation.py --validation-set data/validation_set.csv --min-f1 0.75
```

Every module in `pipeline/` has been syntax-checked and smoke-tested
(see the "tested in this session" note in `docs/enterprise_blueprint.md`
§2) — including catching and fixing a real duplicate-column bug in the
star-schema builder before delivery.

Point Power BI Desktop at the parquet files in `data/curated/` (Get Data
▸ Folder, or Get Data ▸ Parquet for each table) and mark `Dim_Date` as
the model's Date table before adding the DAX measures from the blueprint.

## Sample dataset

`data/raw_reviews_sample_650.csv` is a synthetic, 566-row dataset sized
for BERTopic to actually form topics (its default `min_topic_size=15`
needs real density per cluster — a handful of rows just collapses into
noise). It spans 60 days across 6 product areas, with a deliberate
negative-sentiment spike injected into "Shipping & Delivery" in the
final week (~50% → ~77% negative) so you have something real to see in
the trend chart, the Power BI WoW alert DAX, and `drift_monitor.py`'s
PSI check.

```bash
python pipeline/main.py --input data/raw_reviews_sample_650.csv --output-dir data/curated
```

Note: sentiment labels come from VADER's own lexicon-based scoring, not
from how the synthetic templates were designed — operational complaint
language ("delayed," "never showed up") often doesn't register as
negative to VADER without stronger emotional words ("terrible,"
"awful," "frustrating"). The templates were tuned with that in mind;
worth keeping in mind if you see a real review that "should" be
negative but comes back neutral — it's a known VADER limitation, not a
bug. Swap in Azure AI Language (`AzureLanguageSentimentEngine`) for
better nuance in production.

## Validation set

`data/validation_set.csv` is a separate, 66-row hand-labeled set (NOT
reused from the training data — validating a model against its own
training text proves nothing). `true_label` is a human ground-truth
judgment, deliberately including hard cases VADER is likely to miss:
operational complaints with no negative-coded words, mild sarcasm, and
mixed-sentiment reviews.

```bash
python pipeline/validation.py --validation-set data/validation_set.csv --min-f1 0.75
```

As shipped, this **correctly fails the default 0.75 F1 gate** — VADER
scores 0.705 macro-F1, with negative-class recall dragging it down to
0.59 (it mislabels many operational complaints as neutral or even
positive). That's the validation framework doing exactly its job: it's
telling you VADER isn't production-ready on its own for this domain.
Options from here: lower the threshold if VADER is acceptable for a
first pass, swap in `AzureLanguageSentimentEngine` and re-validate, or
extend the sentiment engine with a rule layer for operational-complaint
phrases.
