"""
main.py
-------
Orchestrates the end-to-end pipeline and materializes the star-schema
tables that Power BI's semantic model reads:

    Fact_Reviews        (grain: one row per review)
    Dim_Product          (product_area)
    Dim_Date              (calendar table)
    Dim_Sentiment         (sentiment label lookup)
    Dim_Topic             (ML topic_id -> keywords)
    drift_log             (append-only drift audit table)
    pii_audit_log          (append-only PII redaction audit table)

Run:
    python main.py --input data/raw_reviews.csv --output-dir data/curated
"""

from __future__ import annotations

import argparse
import logging
import os
from datetime import datetime

import pandas as pd

from pii_scrubber import scrub_dataframe
from sentiment_topic_analysis import run_analysis
from drift_monitor import run_drift_checks, append_drift_log

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("reviews_pipeline.main")


def build_dim_date(min_date, max_date) -> pd.DataFrame:
    dates = pd.date_range(min_date, max_date, freq="D")
    dim_date = pd.DataFrame({"date_key": dates.strftime("%Y%m%d").astype(int), "date": dates})
    dim_date["year"] = dim_date["date"].dt.year
    dim_date["quarter"] = dim_date["date"].dt.quarter
    dim_date["month"] = dim_date["date"].dt.month
    dim_date["month_name"] = dim_date["date"].dt.strftime("%B")
    dim_date["week_of_year"] = dim_date["date"].dt.isocalendar().week
    dim_date["day_of_week"] = dim_date["date"].dt.day_name()
    dim_date["is_weekend"] = dim_date["date"].dt.dayofweek >= 5
    return dim_date


def build_star_schema(df: pd.DataFrame, output_dir: str):
    os.makedirs(output_dir, exist_ok=True)

    df["review_date"] = pd.to_datetime(df["review_date"])
    df["date_key"] = df["review_date"].dt.strftime("%Y%m%d").astype(int)

    dim_product = (
        df[["product_area"]]
        .drop_duplicates()
        .reset_index(drop=True)
        .reset_index()
        .rename(columns={"index": "product_area_key"})
    )
    dim_topic = (
        df[["topic_id", "topic_keywords"]]
        .drop_duplicates(subset="topic_id")
        .reset_index(drop=True)
    )
    dim_sentiment = pd.DataFrame(
        {
            "sentiment_key": [1, 2, 3],
            "sentiment_label": ["negative", "neutral", "positive"],
        }
    )
    dim_date = build_dim_date(df["review_date"].min(), df["review_date"].max())

    fact_reviews = df.merge(dim_product, on="product_area", how="left").merge(
        dim_sentiment, on="sentiment_label", how="left"
    )
    base_cols = [
        "review_id",
        "date_key",
        "product_area_key",
        "sentiment_key",
        "topic_id",
        "sentiment_score",
        "sentiment_confidence",
        "review_text_scrubbed",
    ]
    if "campaign_id" in fact_reviews.columns:
        base_cols.append("campaign_id")  # optional degenerate dim for A/B campaign comparison
    fact_reviews = fact_reviews[base_cols].rename(
        columns={"review_text_scrubbed": "review_text_clean"}
    )

    fact_reviews.to_parquet(os.path.join(output_dir, "Fact_Reviews.parquet"), index=False)
    dim_product.to_parquet(os.path.join(output_dir, "Dim_Product.parquet"), index=False)
    dim_date.to_parquet(os.path.join(output_dir, "Dim_Date.parquet"), index=False)
    dim_sentiment.to_parquet(os.path.join(output_dir, "Dim_Sentiment.parquet"), index=False)
    dim_topic.to_parquet(os.path.join(output_dir, "Dim_Topic.parquet"), index=False)

    # Denormalized, human-readable CSV — not part of the Power BI star schema,
    # just a convenience export for the quick-look HTML dashboard (see
    # docs/dashboard_preview.html) so results are inspectable without
    # opening Power BI Desktop.
    preview = (
        fact_reviews.merge(dim_product, on="product_area_key", how="left")
        .merge(dim_sentiment, on="sentiment_key", how="left")
        .merge(dim_topic, on="topic_id", how="left")
        .merge(dim_date, on="date_key", how="left")
    )[
        [
            "review_id",
            "date",
            "product_area",
            "sentiment_label",
            "sentiment_score",
            "sentiment_confidence",
            "topic_keywords",
            "review_text_clean",
        ]
    ]
    preview.to_csv(os.path.join(output_dir, "dashboard_export.csv"), index=False)

    logger.info("Star schema written to %s (%d fact rows).", output_dir, len(fact_reviews))
    return fact_reviews, dim_product, dim_date, dim_sentiment, dim_topic


def run_pipeline(input_path: str, output_dir: str, baseline_path: str | None = None):
    os.makedirs(output_dir, exist_ok=True)

    logger.info("Loading raw reviews from %s", input_path)
    raw_df = pd.read_csv(input_path)

    logger.info("Step 1/4: Scrubbing PII ...")
    scrubbed_df, pii_audit = scrub_dataframe(raw_df, text_col="review_text", id_col="review_id")
    pd.DataFrame([r.__dict__ for r in pii_audit]).to_csv(
        os.path.join(output_dir, "pii_audit_log.csv"), index=False
    )

    logger.info("Step 2/4: Running sentiment + topic analysis ...")
    analyzed_df = run_analysis(scrubbed_df, text_col="review_text_scrubbed")

    logger.info("Step 3/4: Writing star-schema tables ...")
    fact_reviews, *_ = build_star_schema(analyzed_df, output_dir)

    logger.info("Step 4/4: Running drift checks ...")
    if baseline_path and os.path.exists(baseline_path):
        baseline_df = pd.read_parquet(baseline_path)
        reports = run_drift_checks(baseline_df, analyzed_df)
        append_drift_log(reports, log_path=os.path.join(output_dir, "drift_log.csv"))
    else:
        logger.warning("No baseline snapshot found; skipping drift check on this run. "
                        "Save this run's output as the baseline once validated.")

    logger.info("Pipeline complete.")
    return analyzed_df


def _cli():
    parser = argparse.ArgumentParser(description="Reviews & Sentiment Dashboard ETL pipeline.")
    parser.add_argument("--input", required=True, help="Path to raw reviews CSV.")
    parser.add_argument("--output-dir", default="data/curated", help="Output directory for star-schema parquet files.")
    parser.add_argument("--baseline", default=None, help="Path to baseline analyzed parquet for drift comparison.")
    args = parser.parse_args()
    run_pipeline(args.input, args.output_dir, args.baseline)


if __name__ == "__main__":
    _cli()
