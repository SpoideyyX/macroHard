"""
validation.py
--------------
Validation framework for the sentiment classifier: scores model output
against a human-labeled validation set and produces Precision / Recall /
F1 (per class, macro, and weighted), a confusion matrix, and a pass/fail
gate for CI/CD promotion of a new model version.

Expected validation set schema (CSV or DataFrame):
    review_id, review_text, true_label   (true_label in {positive, neutral, negative})

Usage:
    python validation.py --validation-set data/validation_set.csv \
                          --min-f1 0.75
"""

from __future__ import annotations

import argparse
import json
import logging
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from typing import Dict, List

logger = logging.getLogger("reviews_pipeline.validation")

LABELS = ["negative", "neutral", "positive"]


@dataclass
class ValidationReport:
    run_at: str
    n_samples: int
    accuracy: float
    precision_macro: float
    recall_macro: float
    f1_macro: float
    precision_weighted: float
    recall_weighted: float
    f1_weighted: float
    per_class: Dict[str, Dict[str, float]]
    confusion_matrix: List[List[int]]
    passed_gate: bool
    min_f1_threshold: float

    def to_json(self, path: str = None) -> str:
        payload = json.dumps(asdict(self), indent=2)
        if path:
            with open(path, "w") as f:
                f.write(payload)
        return payload


def compute_validation_report(
    y_true: List[str], y_pred: List[str], min_f1_threshold: float = 0.75
) -> ValidationReport:
    from sklearn.metrics import (
        precision_recall_fscore_support,
        accuracy_score,
        confusion_matrix,
    )

    precision, recall, f1, support = precision_recall_fscore_support(
        y_true, y_pred, labels=LABELS, zero_division=0
    )
    per_class = {
        label: {
            "precision": round(float(precision[i]), 4),
            "recall": round(float(recall[i]), 4),
            "f1": round(float(f1[i]), 4),
            "support": int(support[i]),
        }
        for i, label in enumerate(LABELS)
    }

    p_macro, r_macro, f1_macro, _ = precision_recall_fscore_support(
        y_true, y_pred, labels=LABELS, average="macro", zero_division=0
    )
    p_weighted, r_weighted, f1_weighted, _ = precision_recall_fscore_support(
        y_true, y_pred, labels=LABELS, average="weighted", zero_division=0
    )
    acc = accuracy_score(y_true, y_pred)
    cm = confusion_matrix(y_true, y_pred, labels=LABELS).tolist()

    return ValidationReport(
        run_at=datetime.now(timezone.utc).isoformat(),
        n_samples=len(y_true),
        accuracy=round(float(acc), 4),
        precision_macro=round(float(p_macro), 4),
        recall_macro=round(float(r_macro), 4),
        f1_macro=round(float(f1_macro), 4),
        precision_weighted=round(float(p_weighted), 4),
        recall_weighted=round(float(r_weighted), 4),
        f1_weighted=round(float(f1_weighted), 4),
        per_class=per_class,
        confusion_matrix=cm,
        passed_gate=bool(f1_macro >= min_f1_threshold),
        min_f1_threshold=min_f1_threshold,
    )


def validate_against_labeled_set(
    validation_csv_path: str, sentiment_engine, min_f1_threshold: float = 0.75
) -> ValidationReport:
    import pandas as pd

    val_df = pd.read_csv(validation_csv_path)
    required_cols = {"review_id", "review_text", "true_label"}
    missing = required_cols - set(val_df.columns)
    if missing:
        raise ValueError(f"Validation set missing required columns: {missing}")

    y_true = val_df["true_label"].tolist()
    y_pred = [sentiment_engine.score(t).label for t in val_df["review_text"]]

    report = compute_validation_report(y_true, y_pred, min_f1_threshold)
    logger.info(
        "Validation run: F1(macro)=%.3f, Accuracy=%.3f, Gate=%s",
        report.f1_macro,
        report.accuracy,
        "PASSED" if report.passed_gate else "FAILED",
    )
    return report


def _cli():
    parser = argparse.ArgumentParser(description="Validate sentiment model against labeled set.")
    parser.add_argument("--validation-set", required=True, help="Path to labeled CSV.")
    parser.add_argument("--min-f1", type=float, default=0.75, help="Minimum macro-F1 to pass CI gate.")
    parser.add_argument("--out", default="validation_report.json", help="Where to write the JSON report.")
    args = parser.parse_args()

    from sentiment_topic_analysis import get_sentiment_engine

    engine = get_sentiment_engine()
    report = validate_against_labeled_set(args.validation_set, engine, args.min_f1)
    report.to_json(args.out)
    print(report.to_json())

    if not report.passed_gate:
        raise SystemExit(
            f"Validation gate FAILED: F1(macro)={report.f1_macro} < threshold {args.min_f1}"
        )


if __name__ == "__main__":
    _cli()
