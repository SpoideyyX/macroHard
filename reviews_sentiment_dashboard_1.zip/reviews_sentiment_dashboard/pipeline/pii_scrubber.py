"""
pii_scrubber.py
----------------
Enterprise PII scrubbing for free-text customer reviews.

Strategy (defense in depth):
  1. Fast regex pass for structurally-predictable PII: emails, phone numbers,
     credit-card-like sequences, SSN-like sequences, and street addresses.
  2. spaCy NER pass for contextual PII: PERSON, GPE/LOC (when part of an
     address-like phrase), and ORG names that match a customer's own company
     (rare in reviews but handled for B2B review sets).
  3. Optional Microsoft Presidio backend (analyzer + anonymizer) for
     enterprise deployments that need auditable, configurable PII policies.
     Presidio is used when installed; otherwise the module transparently
     falls back to the regex + spaCy engine so the pipeline never hard-fails
     in an environment where Presidio hasn't been provisioned yet.

Design notes:
  - Scrubbing is idempotent: running scrub_pii() twice on the same text
    yields the same result.
  - Every redaction is logged (entity type + span) to `PIIAuditRecord` so
    Data Governance can prove what was removed, without storing the
    original sensitive value.
  - Text is normalized (unicode NFKC, whitespace collapse) before matching
    to defeat simple obfuscation (e.g., "j o h n @ gmail . com").
"""

from __future__ import annotations

import re
import json
import logging
import unicodedata
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Optional

logger = logging.getLogger("reviews_pipeline.pii_scrubber")

# --------------------------------------------------------------------------
# Optional heavy dependencies — loaded lazily / defensively
# --------------------------------------------------------------------------
try:
    import spacy

    _SPACY_AVAILABLE = True
except ImportError:  # pragma: no cover
    _SPACY_AVAILABLE = False

try:
    from presidio_analyzer import AnalyzerEngine
    from presidio_anonymizer import AnonymizerEngine
    from presidio_anonymizer.entities import OperatorConfig

    _PRESIDIO_AVAILABLE = True
except ImportError:  # pragma: no cover
    _PRESIDIO_AVAILABLE = False


# --------------------------------------------------------------------------
# Regex library — kept explicit and testable rather than one mega-pattern
# --------------------------------------------------------------------------
REGEX_PATTERNS = {
    "EMAIL": re.compile(
        r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"
    ),
    "PHONE": re.compile(
        r"(?:(?:\+?\d{1,3}[\s.\-]?)?(?:\(?\d{3}\)?[\s.\-]?)\d{3}[\s.\-]?\d{4})"
    ),
    "SSN": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "CREDIT_CARD": re.compile(
        r"\b(?:\d[ \-]*?){13,16}\b"
    ),
    "ZIP_ADDRESS": re.compile(
        r"\b\d{1,5}\s+([A-Za-z0-9.\-]+\s){1,4}"
        r"(?:Street|St|Avenue|Ave|Road|Rd|Boulevard|Blvd|Lane|Ln|Drive|Dr|"
        r"Court|Ct|Way|Place|Pl)\b\.?,?\s*(?:[A-Za-z\s]+,)?\s*[A-Z]{2}\s*\d{5}(-\d{4})?"
    ),
    "IP_ADDRESS": re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
}

REGEX_LABEL_TOKEN = {
    "EMAIL": "[REDACTED_EMAIL]",
    "PHONE": "[REDACTED_PHONE]",
    "SSN": "[REDACTED_SSN]",
    "CREDIT_CARD": "[REDACTED_CARD]",
    "ZIP_ADDRESS": "[REDACTED_ADDRESS]",
    "IP_ADDRESS": "[REDACTED_IP]",
}

SPACY_ENTITY_TOKEN = {
    "PERSON": "[REDACTED_NAME]",
    "GPE": "[REDACTED_LOCATION]",
    "LOC": "[REDACTED_LOCATION]",
    "FAC": "[REDACTED_LOCATION]",
}

_SPACY_MODEL_NAME = "en_core_web_sm"
_nlp = None  # lazy singleton


def _get_spacy_model():
    global _nlp
    if _nlp is None and _SPACY_AVAILABLE:
        try:
            _nlp = spacy.load(_SPACY_MODEL_NAME, disable=["parser", "lemmatizer"])
        except OSError:
            logger.warning(
                "spaCy model '%s' not found locally; falling back to regex-only "
                "PII scrubbing. Run `python -m spacy download %s` to enable NER.",
                _SPACY_MODEL_NAME,
                _SPACY_MODEL_NAME,
            )
            _nlp = False  # sentinel: tried and failed
    return _nlp or None


@dataclass
class PIIAuditRecord:
    review_id: str
    entity_type: str
    char_start: int
    char_end: int
    engine: str  # "regex" | "spacy" | "presidio"
    scrubbed_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def to_json(self) -> str:
        return json.dumps(self.__dict__)


def _normalize(text: str) -> str:
    text = unicodedata.normalize("NFKC", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _scrub_with_presidio(text: str, review_id: str) -> tuple[str, List[PIIAuditRecord]]:
    analyzer = AnalyzerEngine()
    anonymizer = AnonymizerEngine()
    results = analyzer.analyze(text=text, language="en")
    operators = {
        r.entity_type: OperatorConfig("replace", {"new_value": f"[REDACTED_{r.entity_type}]"})
        for r in results
    }
    anonymized = anonymizer.anonymize(text=text, analyzer_results=results, operators=operators)
    audit = [
        PIIAuditRecord(review_id, r.entity_type, r.start, r.end, "presidio")
        for r in results
    ]
    return anonymized.text, audit


def _scrub_with_regex_and_spacy(text: str, review_id: str) -> tuple[str, List[PIIAuditRecord]]:
    audit: List[PIIAuditRecord] = []
    working = text

    # Regex pass — deterministic, order matters (address before generic digits)
    for label in ("EMAIL", "ZIP_ADDRESS", "SSN", "CREDIT_CARD", "PHONE", "IP_ADDRESS"):
        pattern = REGEX_PATTERNS[label]

        def _replace(match: re.Match) -> str:
            audit.append(
                PIIAuditRecord(
                    review_id, label, match.start(), match.end(), "regex"
                )
            )
            return REGEX_LABEL_TOKEN[label]

        working = pattern.sub(_replace, working)

    # spaCy pass — contextual entities (names, locations)
    nlp = _get_spacy_model()
    if nlp is not None:
        doc = nlp(working)
        # Replace back-to-front so char offsets stay valid
        spans = [
            (ent.start_char, ent.end_char, ent.label_)
            for ent in doc.ents
            if ent.label_ in SPACY_ENTITY_TOKEN
        ]
        for start, end, label in sorted(spans, key=lambda s: s[0], reverse=True):
            token = SPACY_ENTITY_TOKEN[label]
            working = working[:start] + token + working[end:]
            audit.append(PIIAuditRecord(review_id, label, start, end, "spacy"))

    return working, audit


def scrub_pii(text: str, review_id: str = "unknown") -> tuple[str, List[PIIAuditRecord]]:
    """
    Scrub PII from a single review's free text.

    Returns:
        (scrubbed_text, audit_records)
    """
    if not text or not text.strip():
        return text, []

    normalized = _normalize(text)

    if _PRESIDIO_AVAILABLE:
        try:
            return _scrub_with_presidio(normalized, review_id)
        except Exception as exc:  # noqa: BLE001 - defensive: never let PII scrubbing crash the pipeline
            logger.error("Presidio scrubbing failed (%s); falling back to regex/spaCy.", exc)

    return _scrub_with_regex_and_spacy(normalized, review_id)


def scrub_dataframe(df, text_col: str = "review_text", id_col: str = "review_id"):
    """
    Vectorized-friendly wrapper for a pandas DataFrame of reviews.
    Adds `review_text_scrubbed` and returns (df, audit_records_flat_list).
    """
    import pandas as pd  # local import keeps this module importable without pandas

    scrubbed_texts = []
    all_audit: List[PIIAuditRecord] = []

    for _, row in df.iterrows():
        clean_text, audit = scrub_pii(row[text_col], review_id=str(row[id_col]))
        scrubbed_texts.append(clean_text)
        all_audit.extend(audit)

    df = df.copy()
    df[f"{text_col}_scrubbed"] = scrubbed_texts
    return df, all_audit


if __name__ == "__main__":
    sample = (
        "Hi, this is John Carter (john.carter@example.com, 415-555-0199). "
        "I ordered from 221B Baker Street, London, NW1 6XE and it never arrived!"
    )
    clean, records = scrub_pii(sample, review_id="R-1001")
    print("Scrubbed:", clean)
    for r in records:
        print(r.to_json())
