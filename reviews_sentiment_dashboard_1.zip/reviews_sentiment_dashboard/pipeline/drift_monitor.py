"""
drift_monitor.py
-----------------
Detects two kinds of drift that matter for a review-sentiment pipeline:

  1. DATA drift — the distribution of INPUT features shifts (e.g., topic
     mix changes because a new product launched, or review length/language
     changes). Measured with Population Stability Index (PSI) on the
     topic/product-area distribution.

  2. MODEL/OUTPUT drift — the distribution of sentiment SCORES the model
     produces shifts even though inputs look similar (a sign the model or
     upstream text processing changed). Measured with a two-sample
     Kolmogorov-Smirnov test on the continuous sentiment_score.

Both checks compare a rolling "current window" (e.g., this week) against a
frozen "baseline window" (e.g., the first 30 days after the model was
validated), and write a row to a `drift_log` table that Power BI's Trend
Alerting page reads directly.

PSI interpretation (industry-standard thresholds):
    PSI < 0.1               -> no significant shift
    0.1 <= PSI < 0.25        -> moderate shift, monitor
    PSI >= 0.25              -> significant shift, investigate/retrain
"""

from __future__ import annotations

import logging
import math
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Dict, List

logger = logging.getLogger("reviews_pipeline.drift_monitor")

PSI_MODERATE_THRESHOLD = 0.10
PSI_SIGNIFICANT_THRESHOLD = 0.25
KS_P_VALUE_ALERT_THRESHOLD = 0.05  # p < 0.05 => distributions differ significantly


@dataclass
class DriftReport:
    checked_at: str
    dimension: str                 # "product_area_distribution" | "sentiment_score"
    metric_name: str                # "PSI" | "KS_statistic"
    metric_value: float
    p_value: float | None
    severity: str                   # "none" | "moderate" | "significant"
    baseline_window: str
    current_window: str


def _population_stability_index(
    baseline_counts: Dict[str, int], current_counts: Dict[str, int]
) -> float:
    """Standard PSI formula: sum((current% - baseline%) * ln(current% / baseline%))
    over all categories, with Laplace smoothing to avoid div-by-zero on
    categories absent from one window (e.g., a brand-new topic)."""
    categories = set(baseline_counts) | set(current_counts)
    baseline_total = sum(baseline_counts.values()) or 1
    current_total = sum(current_counts.values()) or 1

    epsilon = 1e-4
    psi = 0.0
    for cat in categories:
        base_pct = max(baseline_counts.get(cat, 0) / baseline_total, epsilon)
        curr_pct = max(current_counts.get(cat, 0) / current_total, epsilon)
        psi += (curr_pct - base_pct) * math.log(curr_pct / base_pct)
    return round(psi, 4)


def _severity_from_psi(psi: float) -> str:
    if psi >= PSI_SIGNIFICANT_THRESHOLD:
        return "significant"
    if psi >= PSI_MODERATE_THRESHOLD:
        return "moderate"
    return "none"


def check_categorical_drift(
    baseline_df,
    current_df,
    column: str = "product_area",
    baseline_window: str = "baseline",
    current_window: str = "current",
) -> DriftReport:
    baseline_counts = baseline_df[column].value_counts().to_dict()
    current_counts = current_df[column].value_counts().to_dict()
    psi = _population_stability_index(baseline_counts, current_counts)

    report = DriftReport(
        checked_at=datetime.now(timezone.utc).isoformat(),
        dimension=f"{column}_distribution",
        metric_name="PSI",
        metric_value=psi,
        p_value=None,
        severity=_severity_from_psi(psi),
        baseline_window=baseline_window,
        current_window=current_window,
    )
    if report.severity != "none":
        logger.warning(
            "Data drift detected on %s: PSI=%.3f (%s)", column, psi, report.severity
        )
    return report


def check_sentiment_score_drift(
    baseline_scores: List[float],
    current_scores: List[float],
    baseline_window: str = "baseline",
    current_window: str = "current",
) -> DriftReport:
    from scipy.stats import ks_2samp

    statistic, p_value = ks_2samp(baseline_scores, current_scores)
    severity = "significant" if p_value < KS_P_VALUE_ALERT_THRESHOLD else "none"

    report = DriftReport(
        checked_at=datetime.now(timezone.utc).isoformat(),
        dimension="sentiment_score",
        metric_name="KS_statistic",
        metric_value=round(float(statistic), 4),
        p_value=round(float(p_value), 4),
        severity=severity,
        baseline_window=baseline_window,
        current_window=current_window,
    )
    if report.severity != "none":
        logger.warning(
            "Output drift detected on sentiment_score: KS=%.3f, p=%.4f",
            statistic,
            p_value,
        )
    return report


def run_drift_checks(baseline_df, current_df) -> List[DriftReport]:
    reports = [
        check_categorical_drift(baseline_df, current_df, column="product_area"),
        check_categorical_drift(baseline_df, current_df, column="sentiment_label"),
        check_sentiment_score_drift(
            baseline_df["sentiment_score"].tolist(),
            current_df["sentiment_score"].tolist(),
        ),
    ]
    return reports


def append_drift_log(reports: List[DriftReport], log_path: str = "data/drift_log.csv"):
    """Append drift results to the drift_log table Power BI reads. Uses a
    simple CSV/parquet sink here; swap for a Delta/Synapse table write in
    production (see architecture doc)."""
    import pandas as pd
    import os

    rows = [r.__dict__ for r in reports]
    new_df = pd.DataFrame(rows)
    if os.path.exists(log_path):
        existing = pd.read_csv(log_path)
        combined = pd.concat([existing, new_df], ignore_index=True)
    else:
        combined = new_df
    combined.to_csv(log_path, index=False)
    return combined


if __name__ == "__main__":
    import pandas as pd

    baseline = pd.DataFrame(
        {
            "product_area": ["Shipping & Delivery"] * 50 + ["Product Quality"] * 50,
            "sentiment_label": ["negative"] * 40 + ["positive"] * 60,
            "sentiment_score": [-0.3] * 40 + [0.6] * 60,
        }
    )
    current = pd.DataFrame(
        {
            "product_area": ["Shipping & Delivery"] * 90 + ["Product Quality"] * 10,
            "sentiment_label": ["negative"] * 70 + ["positive"] * 30,
            "sentiment_score": [-0.5] * 70 + [0.5] * 30,
        }
    )
    reports = run_drift_checks(baseline, current)
    for r in reports:
        print(r)
