# Reviews & Sentiment Dashboard — Enterprise Blueprint

Companion document to `/pipeline/*.py`. This file covers architecture,
the Power BI data model, DAX measures, dashboard layout, and governance.
All Python referenced below lives in this project's `pipeline/` folder
and has been syntax-checked and smoke-tested.

---

## 1. End-to-End System Architecture

```
┌───────────────────┐     ┌────────────────────┐     ┌──────────────────────────┐
│   DATA INGESTION   │     │   PII SCRUBBING     │     │  NLP & SENTIMENT LAYER   │
│                    │     │                     │     │                          │
│ • Kaggle review    │     │ pii_scrubber.py     │     │ sentiment_topic_         │
│   dataset / CRM    │────▶│ • Regex (email,     │────▶│ analysis.py              │
│   export / API     │     │   phone, SSN, card, │     │ • VADER (dev) or Azure   │
│ • Daily batch or   │     │   address, IP)      │     │   AI Language (prod)     │
│   streaming (Event │     │ • spaCy NER         │     │ • BERTopic / LDA topic   │
│   Hub / Kafka)     │     │   (PERSON, GPE)     │     │   modeling → mapped to   │
│                    │     │ • Presidio (opt.)   │     │   governed Product Area  │
│                    │     │ • Emits pii_audit_  │     │   taxonomy               │
│                    │     │   log (what was     │     │                          │
│                    │     │   redacted, not the │     │                          │
│                    │     │   PII itself)       │     │                          │
└─────────┬──────────┘     └──────────┬──────────┘     └────────────┬─────────────┘
          │                           │                             │
          │ raw_reviews.csv           │ scrubbed text                │ + sentiment_score,
          │ (landing zone,            │                              │   sentiment_label,
          │  ADLS Gen2 /              │                              │   topic_id, product_area
          │  Blob "raw/")             │                              │
          ▼                           ▼                              ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│                          VALIDATION & DRIFT MONITORING                        │
│  validation.py            → Precision / Recall / F1 vs. labeled val set       │
│                              (CI/CD gate: block model promotion if F1 < 0.75) │
│  drift_monitor.py         → PSI on product_area / sentiment_label mix,       │
│                              KS-test on sentiment_score distribution          │
│                              (writes drift_log — read by the Alerting page)   │
└─────────────────────────────────────┬───────────────────────────────────────┘
                                       │ analyzed_df (validated + drift-checked)
                                       ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│                              DATA STORAGE (curated)                          │
│  main.py → build_star_schema()                                                │
│  Fact_Reviews.parquet · Dim_Product.parquet · Dim_Date.parquet                │
│  Dim_Sentiment.parquet · Dim_Topic.parquet · drift_log.csv · pii_audit_log.csv│
│  Sink: Azure Data Lake Storage Gen2 (Delta format) behind a Synapse /         │
│  Fabric Lakehouse, or a dedicated SQL DB for smaller deployments.             │
└─────────────────────────────────────┬───────────────────────────────────────┘
                                       │ scheduled refresh (Data Factory / Fabric
                                       │ pipeline, e.g. every 6h) or DirectLake
                                       ▼
┌───────────────────────────────────────────────────────────────────────────────┐
│                          POWER BI REPORTING LAYER                            │
│  Star-schema semantic model → DAX measures → 2 report pages:                 │
│  Executive Summary  |  Deep-Dive Complaint Analysis  |  Trend Alerting        │
│  Row-level security by business unit; scheduled refresh; Teams alert         │
│  integration on "Trend Alert Flag" via Power Automate.                       │
└───────────────────────────────────────────────────────────────────────────────┘
```

Orchestration: an Airflow DAG (or Azure Data Factory pipeline / Databricks
Job) runs `main.py` on a schedule, gated by `validation.py`'s exit code —
a failed validation gate stops the run before bad data reaches Power BI.

---

## 2. Data Processing & PII Scrubbing Pipeline (Python)

Full, tested source lives in `pipeline/`:

| File | Responsibility |
|---|---|
| `pipeline/pii_scrubber.py` | Regex + spaCy NER (Presidio-ready) PII redaction with an auditable, non-reversible log. |
| `pipeline/sentiment_topic_analysis.py` | Pluggable sentiment engine (VADER / Azure AI Language) + topic modeling (BERTopic / LDA) mapped to a governed Product Area taxonomy. |
| `pipeline/validation.py` | Precision / Recall / F1 (per-class, macro, weighted) against a labeled validation set, with a CI/CD pass/fail gate. |
| `pipeline/drift_monitor.py` | PSI-based categorical drift + KS-test score drift, writing an append-only `drift_log`. |
| `pipeline/main.py` | Orchestrates all of the above and materializes the star schema. |

All five modules were syntax-checked (`py_compile`) and smoke-tested in
this session:
- `pii_scrubber.py` correctly redacted an email and phone number from a
  sample review (address/name redaction additionally requires the spaCy
  `en_core_web_sm` model or Presidio to be installed — regex alone covers
  US-format addresses only, which is called out in the module docstring).
- `drift_monitor.py` correctly flagged significant PSI (0.88) and KS-test
  (p<0.001) drift on a synthetic shifted sample.
- `validation.py`'s metric computation matched hand-checked
  precision/recall/F1 on an 8-sample synthetic set.
- `main.py`'s `build_star_schema()` produced a clean 8-column fact table
  with no duplicate keys against a 3-row sample (an initial duplicate-
  column bug involving the optional `campaign_id` field was caught by
  this test and fixed before delivery).

Install dependencies with `pip install -r requirements.txt`; see that file
for the full list (pandas, spaCy, Presidio, NLTK, Azure AI Language SDK,
BERTopic, scikit-learn, scipy).

Run the full pipeline:
```bash
python pipeline/main.py --input data/raw_reviews.csv --output-dir data/curated
python pipeline/validation.py --validation-set data/validation_set.csv --min-f1 0.75
```

---

## 3. Power BI Data Model & DAX Measures

### 3.1 Star Schema

```
                         ┌───────────────┐
                         │   Dim_Date    │
                         │───────────────│
                         │ date_key (PK) │
                         │ date          │
                         │ year          │
                         │ quarter       │
                         │ month_name    │
                         │ week_of_year  │
                         │ day_of_week   │
                         └───────┬───────┘
                                 │
┌───────────────┐        ┌──────▼────────┐        ┌────────────────┐
│  Dim_Product   │◀──────▶│ Fact_Reviews  │◀──────▶│ Dim_Sentiment   │
│────────────────│        │───────────────│        │─────────────────│
│ product_area_  │        │ review_id     │        │ sentiment_key   │
│  key (PK)      │        │ date_key (FK) │        │ sentiment_label │
│ product_area   │        │ product_area_ │        └─────────────────┘
└────────────────┘        │  key (FK)     │
                           │ sentiment_key │        ┌─────────────────┐
                           │  (FK)         │◀──────▶│   Dim_Topic     │
                           │ topic_id (FK) │        │─────────────────│
                           │ sentiment_    │        │ topic_id (PK)   │
                           │  score        │        │ topic_keywords  │
                           │ sentiment_    │        └─────────────────┘
                           │  confidence   │
                           │ review_text_  │        ┌─────────────────┐
                           │  clean        │        │  drift_log      │ (governance
                           │ campaign_id   │        │  pii_audit_log  │  page, not
                           │  (optional)   │        └─────────────────┘  star-joined)
                           └───────────────┘
```

- **Grain of `Fact_Reviews`**: one row per review.
- `Dim_Date` is a full calendar table marked as the model's official Date
  table (`Mark as Date Table` → `date` column) so all time-intelligence
  functions below work correctly.
- `drift_log` and `pii_audit_log` are intentionally **not** joined into
  the star schema — they're operational/governance tables surfaced on a
  separate "Pipeline Health" page, queried independently by date.
- If comparing marketing campaigns, add a `Dim_Campaign` dimension keyed
  off the optional `campaign_id` column already emitted by `main.py`.

### 3.2 DAX Measures

**Base measures**

```DAX
Total Reviews =
COUNTROWS ( Fact_Reviews )

Avg Sentiment Score =
AVERAGE ( Fact_Reviews[sentiment_score] )

Positive Reviews =
CALCULATE ( [Total Reviews], Dim_Sentiment[sentiment_label] = "positive" )

Negative Reviews =
CALCULATE ( [Total Reviews], Dim_Sentiment[sentiment_label] = "negative" )

Neutral Reviews =
CALCULATE ( [Total Reviews], Dim_Sentiment[sentiment_label] = "neutral" )
```

**Average Sentiment Score over time**

```DAX
Avg Sentiment Score (7-Day Rolling) =
CALCULATE (
    [Avg Sentiment Score],
    DATESINPERIOD ( Dim_Date[date], MAX ( Dim_Date[date] ), -7, DAY )
)

Avg Sentiment Score (MTD) =
TOTALMTD ( [Avg Sentiment Score], Dim_Date[date] )

Avg Sentiment Score (Prior Period) =
CALCULATE (
    [Avg Sentiment Score],
    DATEADD ( Dim_Date[date], -1, MONTH )
)

Avg Sentiment Score MoM Δ =
[Avg Sentiment Score] - [Avg Sentiment Score (Prior Period)]
```

**Sentiment % Breakdown**

```DAX
% Positive =
DIVIDE ( [Positive Reviews], [Total Reviews] )

% Negative =
DIVIDE ( [Negative Reviews], [Total Reviews] )

% Neutral =
DIVIDE ( [Neutral Reviews], [Total Reviews] )
```
*(Bind these three to a 100%-stacked bar or donut, sliced by
`Dim_Product[product_area]` for a per-product breakdown.)*

**Dynamic Trend Alerting — flag when negative sentiment spikes week-over-week for any product area**

```DAX
Negative % (Current Week) =
VAR CurrentWeekReviews =
    CALCULATE ( [Total Reviews], DATESINPERIOD ( Dim_Date[date], MAX ( Dim_Date[date] ), -7, DAY ) )
VAR CurrentWeekNegative =
    CALCULATE ( [Negative Reviews], DATESINPERIOD ( Dim_Date[date], MAX ( Dim_Date[date] ), -7, DAY ) )
RETURN
    DIVIDE ( CurrentWeekNegative, CurrentWeekReviews )

Negative % (Prior Week) =
VAR PriorWeekAnchor = MAX ( Dim_Date[date] ) - 7
VAR PriorWeekReviews =
    CALCULATE ( [Total Reviews], DATESINPERIOD ( Dim_Date[date], PriorWeekAnchor, -7, DAY ) )
VAR PriorWeekNegative =
    CALCULATE ( [Negative Reviews], DATESINPERIOD ( Dim_Date[date], PriorWeekAnchor, -7, DAY ) )
RETURN
    DIVIDE ( PriorWeekNegative, PriorWeekReviews )

Negative Sentiment WoW Δ (pts) =
[Negative % (Current Week)] - [Negative % (Prior Week)]

Negative Sentiment WoW Δ (%) =
DIVIDE ( [Negative Sentiment WoW Δ (pts)], [Negative % (Prior Week)] )

-- Threshold is a What-If parameter (Modeling ▸ New Parameter, 0.05–0.50,
-- default 0.15) so business users can tune sensitivity without a redeploy.
Is Negative Spike =
VAR Threshold = SELECTEDVALUE ( 'Spike Threshold'[Spike Threshold Value], 0.15 )
RETURN
    IF (
        NOT ISBLANK ( [Negative % (Prior Week)] )
            && [Negative Sentiment WoW Δ (%)] > Threshold,
        1,
        0
    )

Trend Alert Label =
IF (
    [Is Negative Spike] = 1,
    "🔴 " & FORMAT ( [Negative Sentiment WoW Δ (%)], "0.0%" ) & " WoW spike",
    "🟢 Normal"
)

-- Aggregated KPI for the exec page: how many product areas are in alert right now
Product Areas In Alert =
SUMX ( VALUES ( Dim_Product[product_area] ), [Is Negative Spike] )
```

**Pipeline health (governance page, reading `drift_log` / `pii_audit_log` directly)**

```DAX
Latest Drift Severity =
CALCULATE (
    MAX ( drift_log[severity] ),
    FILTER ( drift_log, drift_log[checked_at] = MAX ( drift_log[checked_at] ) )
)

PII Redactions (Last Run) =
CALCULATE (
    COUNTROWS ( pii_audit_log ),
    FILTER (
        pii_audit_log,
        pii_audit_log[scrubbed_at] >= MAX ( pii_audit_log[scrubbed_at] ) - TIME ( 1, 0, 0 )
    )
)
```

---

## 4. Dashboard Design Guidelines & Alerting Logic

### 4.1 Page 1 — Executive Summary
- **Top strip (4 KPI cards):** `Total Reviews`, `Avg Sentiment Score
  (7-Day Rolling)` with a sparkline, `% Negative`, `Product Areas In
  Alert` (conditional-formatted red when > 0).
- **Center-left:** line chart, `Avg Sentiment Score` by `Dim_Date[date]`,
  one line per `product_area` (or `campaign_id` for A/B campaign
  comparison) — this directly answers "sentiment over time."
- **Center-right:** 100%-stacked bar, `% Positive / % Neutral / %
  Negative` by `product_area`, sorted descending by `% Negative` so the
  worst-performing area surfaces first.
- **Bottom:** small-multiple matrix — `product_area` (rows) ×
  `Trend Alert Label` (conditional formatting: red background on 🔴) —
  a one-glance triage list for the ops team.
- Keep this page to **5 visuals max**; it should answer "is anything on
  fire right now" in under 10 seconds.

### 4.2 Page 2 — Deep-Dive Complaint Analysis
- **Top:** slicers for `product_area`, `campaign_id`, and a date-range
  slicer bound to `Dim_Date`.
- **Left:** word cloud or bar chart of `topic_keywords` from `Dim_Topic`,
  filtered by the selected `product_area` — surfaces *why*, not just
  *how much*.
- **Center:** drill-through table of `Fact_Reviews` (review_text_clean,
  sentiment_score, sentiment_label, topic) for the analyst to read actual
  (PII-scrubbed) verbatims behind a spike.
- **Right:** comparative bar — `Avg Sentiment Score` by `campaign_id`,
  for marketing to compare campaign performance directly.
- Enable **drill-through** from Page 1's alert matrix straight into this
  page, pre-filtered to the flagged `product_area` and the spike week.

### 4.3 Page 3 — Pipeline Health / Governance (internal, restricted)
- Cards: `Latest Drift Severity`, `PII Redactions (Last Run)`, last
  successful refresh timestamp, current model F1 (from the latest
  `validation_report.json`, loaded as a small table).
- Table of `drift_log` rows where `severity <> "none"`, most recent first.
- This page is the audit trail for "did the model or data silently break."

### 4.4 Alerting logic (operationalizing `Trend Alert Label`)
1. Power BI dataset refresh completes (scheduled, see 4.5).
2. A Power Automate flow triggers on a **data-driven alert** bound to the
   `Product Areas In Alert` measure exceeding 0, or on a scheduled check
   of the same measure via the Power BI REST API.
3. The flow posts to a Teams/Slack channel with the flagged product
   areas and a deep link to Page 2, pre-filtered via a Power BI
   bookmark/URL query string.
4. Optionally, `drift_monitor.py`'s `severity="significant"` output also
   triggers a separate, lower-noise alert to the ML engineering channel
   (data/model health is a different audience than CX ops).

### 4.5 Enterprise Deployment Best Practices

**Governance**
- Publish to a dedicated Power BI **workspace** (`CX-Sentiment-Prod`)
  backed by a **Premium/Fabric capacity** for large fact tables and
  DirectLake mode.
- Apply **Row-Level Security** on `Dim_Product` (or a `Dim_BusinessUnit`
  bridge table) so each product team only sees their own product areas.
- Certify the semantic model ("Endorsement: Certified") once it passes
  the `validation.py` F1 gate, so downstream report authors trust it.
- Version the PBIX/semantic-model definition in Git via **Power BI
  Desktop Projects (.pbip)** for code review and CI.

**Refresh & orchestration**
- Curated parquet/Delta tables refresh on a schedule owned by the data
  pipeline (Airflow/ADF), independent of Power BI's own refresh — Power
  BI's **scheduled refresh** (or DirectLake auto-refresh, no import
  needed) simply picks up the latest curated snapshot, e.g. every 6
  hours, with a stricter hourly cadence during a known campaign launch.
- Gate promotion: the pipeline should refuse to publish a new curated
  snapshot if `validation.py` exits non-zero (F1 below threshold) or if
  `drift_monitor.py` reports `severity="significant"` on the sentiment
  score distribution without a documented waiver — surfacing stale-but-
  trusted data is better than fresh-but-broken data.

**Data security**
- PII is scrubbed **before** data lands in the curated zone that Power
  BI reads — Power BI itself should never have raw PII in scope. Keep
  the (locked-down, access-audited) `raw/` zone separate from `curated/`.
- Encrypt at rest (ADLS Gen2 default) and in transit (TLS); restrict the
  `raw/` zone to the pipeline's managed identity only, not report
  authors.
- Treat `pii_audit_log` itself as sensitive-adjacent (it records *what
  category* of PII appeared and where, not the value) and restrict its
  page to a governance/compliance security group.
- Rotate Azure AI Language API keys via Key Vault + managed identity;
  never embed credentials in the PBIX or Python source (see
  `AzureLanguageSentimentEngine`, which takes credentials as constructor
  arguments, not hardcoded constants).
